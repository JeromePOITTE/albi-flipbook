FLIPBOOK ALBI 2026 — INSTALLATION WIX

Contenu : index.html + dossier pages/

1. Hébergez le dossier complet sur un hébergement HTTPS accessible publiquement.
2. Notez l'adresse publique de index.html, par exemple : https://votre-hebergement.fr/albi/index.html
3. Dans Wix, ajoutez un élément « Intégrer du code » / « Intégrer un site » (HTML iframe).
4. Utilisez l'adresse publique du fichier index.html.
5. Dimension conseillée sur ordinateur : largeur 100 %, hauteur 700 à 780 px.
6. Sur mobile : largeur 100 %, hauteur 520 à 650 px selon votre mise en page.

Exemple de code iframe (remplacer URL_DU_FLIPBOOK) :
<iframe src="URL_DU_FLIPBOOK" width="100%" height="760" style="border:0" allow="fullscreen" loading="lazy" title="Feuilleter Albi — Merveille de briques et de lumière"></iframe>

Le flipbook fonctionne sans abonnement à un service de flipbook et sans bibliothèque JavaScript externe.
